﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace txt2SQLTable
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Job Started");
            Console.WriteLine("------------------------------------------");
            DateTime start = DateTime.Now;
            ReadingfromTXT txtFile = new ReadingfromTXT();
            txtFile.txtfiles();
            DateTime end = DateTime.Now;
            Console.WriteLine("Job Completed");
            Console.WriteLine("------------------------------------------");
            int timetaken = (int) (end - start).TotalMinutes;
            Console.WriteLine("Total Time Taken to insert the records : " + timetaken + " minutes");
            Console.ReadLine();
        }
    }
}
