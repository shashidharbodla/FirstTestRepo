﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace txt2SQLTable.Model
{
    class Messages
    {
        public string AccNo { get; set; }
        public string DiscountCode { get; set; }
        public Guid BarCode { get; set; }
        public Guid EncodingType { get; set; }
        public string DiscountRate { get; set; }
        public int brandid { get; set; }


    }

    class JsonInfo
    {
        [JsonProperty(PropertyName = "FileName")]
        public string FileName { get; set; }

        [JsonProperty(PropertyName = "Brand")]
        public string Brand { get; set; }

        [JsonProperty(PropertyName = "AccountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty(PropertyName = "LinkedCouponID")]
        public string LinkedCouponID { get; set; }

        [JsonProperty(PropertyName = "DiscountCode")]
        public string DiscountCode { get; set; }

        [JsonProperty(PropertyName = "BarcodeType")]
        public string BarcodeType { get; set; }

        [JsonProperty(PropertyName = "EncodingType")]
        public string EncodingType { get; set; }

        [JsonProperty(PropertyName = "EffectiveDate")]
        public string EffectiveDate { get; set; }

        [JsonProperty(PropertyName = "TerminationDate")]
        public string TerminationDate { get; set; }

    }

    class answers
    {
        [JsonProperty(PropertyName = "FileInfo")]
        public List<JsonInfo> FileInfo { get; set; }
    }

}
