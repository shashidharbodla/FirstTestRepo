﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using txt2SQLTable.Model;

namespace txt2SQLTable
{
    class SharedDetails
    {
        static SqlConnection con;
        public static DataTable GettxtDataFromFile(FileInfo file, DataTable tblcsv)
        {
            //getting full file path of Uploaded file  
            string TxtFilePath = Path.GetFullPath(file.FullName);

            //Reading All text  
            string ReadTxt = File.ReadAllText(TxtFilePath);
            //spliting row after new line  
            foreach (string txtRow in ReadTxt.Split('\n'))
            {
                if (!string.IsNullOrEmpty(txtRow))
                {
                    //Adding each row into datatable  
                    tblcsv.Rows.Add();
                    tblcsv.Rows[tblcsv.Rows.Count - 1][0] = txtRow.Replace("\"", "").Trim();

                }
            }

            //tblcsv.Rows[0].Delete();
            tblcsv.AcceptChanges();
            return tblcsv;
        }

        /*
        public static string SelectBrandDetails(string Brand)
        {
            switch (Brand)
            {
                case "MARLBORO":
                    return "27";

                case "REDSEAL":
                    return "2700";

                case "FRESHCOPE":
                    return "2400";
                default:
                    return "27";
            }
        }
        */
        public static void connection()
        {
            con = new SqlConnection(ConfigurationManager.AppSettings["sqlconnection"]);

        }

        public static Messages Details(JsonInfo item)
        {
            try
            { 
            Messages objMessage = new Messages();

            objMessage.AccNo = item.AccountNumber;
                objMessage.DiscountCode = item.DiscountCode; //float.Parse(item.PricePoint, System.Globalization.CultureInfo.InvariantCulture); 
            var barcode = "select BarcodeTypeGUID from SEP_BarcodeType where Active = 1 and  BarCodeTypeCode = '" + item.BarcodeType + "'";
            var EncodingType = "select EncodingTypeGUID from SEP_BarcodeEncodingType where Active = 1 and  EncodingTypeCode = '" + item.EncodingType + "'";
            var DiscountRate = "select DiscountRateID from DVP_DiscountRate where Active = 1 and DiscountCode = '" + item.DiscountCode + "'";
            var BrandID = "select brandID from GTC_Client where Active = 1 and ClientCode = '" + item.Brand +"'";

            connection();

            con.Open();
            SqlCommand cmd1 = new SqlCommand(barcode, con);
            objMessage.BarCode = Guid.Parse(cmd1.ExecuteScalar().ToString());
            cmd1.CommandText = EncodingType;
            objMessage.EncodingType = Guid.Parse(cmd1.ExecuteScalar().ToString());
            cmd1.CommandText = DiscountRate;
            objMessage.DiscountRate = cmd1.ExecuteScalar().ToString();
            cmd1.CommandText = BrandID;
            objMessage.brandid = Convert.ToInt32(cmd1.ExecuteScalar());
            con.Close();
            //SqlCommand cmd2 = new SqlCommand(EncodingType, con);
            //SqlCommand cmd3 = new SqlCommand(DiscountRate, con);



            return objMessage;
            }
            catch(Exception ex)
            {
                if(ex is System.Data.SqlClient.SqlException)
                { 
                    Console.WriteLine("Error Occured : ");
                    Console.WriteLine("Please check the Connection String for the Database");
                    Console.WriteLine("Job Not Completed");
                    Console.WriteLine("------------------------------------------");
                    Console.ReadLine();
                    System.Environment.Exit(-1);
                }
                return null;
            }
        }

        public static void InsertCSVRecords(DataTable csvdt)
        {
            try
            { 
            connection();
            //creating object of SqlBulkCopy    
            SqlBulkCopy objbulk = new SqlBulkCopy(con);

            //assigning Destination table name    
            objbulk.DestinationTableName = "[ETL].[UniqueCoupon]";
            //Mapping Table column 
            objbulk.ColumnMappings.Add("UniqueCouponID", "UniqueCouponID");
            objbulk.ColumnMappings.Add("BrandID", "BrandID");
            objbulk.ColumnMappings.Add("BarCodeTypeGUID", "BarCodeTypeGUID");
            objbulk.ColumnMappings.Add("UsedInd", "UsedInd");
            objbulk.ColumnMappings.Add("DiscountRateID", "DiscountRateID");
            objbulk.ColumnMappings.Add("ProcessedInd", "ProcessedInd");
            objbulk.ColumnMappings.Add("CouponCode", "CouponCode");
            objbulk.ColumnMappings.Add("AccountNumber", "AccountNumber");
            objbulk.ColumnMappings.Add("LinkedCouponID", "LinkedCouponID");
            objbulk.ColumnMappings.Add("CreateDate", "CreateDate");
            objbulk.ColumnMappings.Add("EffectiveDate", "EffectiveDate");
            objbulk.ColumnMappings.Add("CreateUser", "CreateUser");
            objbulk.ColumnMappings.Add("TerminationDate", "TerminationDate");
            objbulk.ColumnMappings.Add("Active", "Active");
            objbulk.ColumnMappings.Add("EncodingTypeGUID", "EncodingTypeGUID");

            objbulk.BulkCopyTimeout = 300;

            //inserting Datatable Records to DataBase    
            con.Open();
            objbulk.WriteToServer(csvdt);
            con.Close();
            }
            catch (Exception ex)
            {
                if (ex is System.Data.SqlClient.SqlException)
                {
                    Console.WriteLine("Error Occured : ");
                    Console.WriteLine("------------------------------------------");
                    Console.WriteLine(ex);
                    Console.WriteLine("------------------------------------------");
                    Console.WriteLine("Job Not Completed");
                    Console.WriteLine("------------------------------------------");
                    Console.ReadLine();
                    System.Environment.Exit(-1);
                }
                //return null;
            }
        }

    }
}
