﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using txt2SQLTable.Model;

namespace txt2SQLTable
{
    class ReadingfromTXT
    {
        string BrandId = string.Empty;
        
        public void txtfiles()
        {
            var currentDirectory = System.IO.Directory.GetCurrentDirectory();
            var filepath = currentDirectory + "\\Speedway";
            GettxtFileData(filepath);
        }

        private answers ReadJsonFile ()
        {
            answers Objans = new answers();

            using (StreamReader reader = new StreamReader("BrandConfig.json"))
            {
                string jsonData = reader.ReadToEnd();
                Objans = JsonConvert.DeserializeObject<answers>(jsonData);
            }

            return Objans;
        }

        private void GettxtFileData(string filepath)
        {
            try { 

                DateTime UtcTime = DateTime.UtcNow;
                string username = "InitLoad";
                int? linkedcoupon = null;
                int count = 0;
                DateTime EffectiveDate;
                DateTime TerminationDate; 
                DirectoryInfo d = new DirectoryInfo(filepath);
                
                answers Objans = new answers();
                Objans = ReadJsonFile();


                foreach (var file in d.GetFiles("*.txt"))
                {
                    count++;
                    Console.WriteLine(file.Name + ":");

                    JsonInfo obj1 = Objans.FileInfo.Where(a => a.FileName == file.Name).FirstOrDefault();
                    if (obj1 != null)
                    {
                        if (!String.IsNullOrEmpty(obj1.LinkedCouponID))
                        {
                            linkedcoupon = Convert.ToInt32(obj1.LinkedCouponID);
                        }
                        EffectiveDate = DateTime.Parse(obj1.EffectiveDate);
                        TerminationDate = DateTime.Parse(obj1.TerminationDate);

                        Messages messages = new Messages();
                        messages = SharedDetails.Details(obj1);

                        DataTable tblcsv = new DataTable();
                        //creating columns  
                        tblcsv.Columns.Add("CouponCode");
                        tblcsv = SharedDetails.GettxtDataFromFile(file, tblcsv);

                        DataTable tbl = new DataTable();
                        //creating columns  
                        tbl.Columns.Add("UniqueCouponID");
                        tbl.Columns.Add("BrandID");
                        tbl.Columns.Add("BarCodeTypeGUID", typeof(Guid));
                        tbl.Columns.Add("UsedIND");
                        tbl.Columns.Add("ProcessedInd");
                        tbl.Columns.Add("DiscountRateID");
                        tbl.Columns.Add("CouponCode");
                        tbl.Columns.Add("AccountNumber");
                        tbl.Columns.Add("LinkedCouponID");
                        tbl.Columns.Add("CreateDate");
                        tbl.Columns.Add("CreateUser");
                        tbl.Columns.Add("EffectiveDate");
                        tbl.Columns.Add("TerminationDate");
                        tbl.Columns.Add("Active");
                        tbl.Columns.Add("EncodingTypeGUID", typeof(Guid));

                        foreach (DataRow item1 in tblcsv.Rows)
                        {
                            DataRow dr = tbl.NewRow();
                            dr["BrandID"] = messages.brandid;
                            dr["BarCodeTypeGUID"] = messages.BarCode;
                            dr["UsedIND"] = false;
                            dr["ProcessedInd"] = false;
                            dr["DiscountRateID"] = messages.DiscountRate;
                            dr["CouponCode"] = item1["CouponCode"];
                            dr["AccountNumber"] = messages.AccNo;
                            dr["LinkedCouponID"] = linkedcoupon;
                            dr["CreateDate"] = UtcTime;
                            dr["CreateUser"] = username;
                            dr["EffectiveDate"] = EffectiveDate;
                            dr["TerminationDate"] = TerminationDate;
                            dr["Active"] = true;
                            dr["EncodingTypeGUID"] = messages.EncodingType;

                            tbl.Rows.Add(dr);
                        }

                        SharedDetails.InsertCSVRecords(tbl);

                        Console.WriteLine("Reading data from the file is Completed ");
                        Console.WriteLine("Inserted " + tbl.Rows.Count + " records from the file");
                        Console.WriteLine("------------------------------------------");
                        //Console.WriteLine(tblcsv.Rows.Count + "Records are Inserted into the Table");

                        Directory.Move(file.FullName, filepath + "\\Completed\\" + file.Name);
                    }

                    else
                    {
                        Console.WriteLine("------------------------------------------");
                        Console.WriteLine("Please provide the correct values for the corresponding file : \n" + file.Name);
                        Console.WriteLine("------------------------------------------");
                        Console.ReadLine();
                        System.Environment.Exit(-1);
                    }
                }

                Console.WriteLine("------------------------------------------");
                Console.WriteLine("---Reading Completed---");
                Console.WriteLine("Total Number of TXT Files Read = " + count);

            }
            catch(Exception ex)
            {
                if(ex is System.FormatException)
                {
                    Console.WriteLine("Error Occured : ");
                    Console.WriteLine("Please check the format of the values that you have entered");
                    Console.WriteLine("Job Not Completed");
                    Console.WriteLine("------------------------------------------");
                    Console.ReadLine();
                    System.Environment.Exit(-1);
                }
            }

        }
    }

}