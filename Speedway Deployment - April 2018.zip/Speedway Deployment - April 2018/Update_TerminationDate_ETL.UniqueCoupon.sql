IF @@SERVERNAME != 'alcazpdmsq01'
/*
Use server name as 'alcazpdmsq01' for QA
                as 'alcazpdmsp01' for PROD
				as 'WMJ00487C' for DevWMJ
*/
BEGIN
      PRINT 'ERROR: INCORRECT SERVER !!'
END

ELSE
BEGIN

IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors

CREATE TABLE #tmpErrors (Error int)

	BEGIN TRANSACTION

    --ROW COUNT : (QA - 7059999; S01 - 5559999; S02 - 5559999; Prod - 5559999;) 
	
	UPDATE 
	--SELECT COUNT(1) FROM
	ETL.UniqueCoupon 
	SET TerminationDate = '9999-12-31', UpdateDate = GETUTCDATE(), UpdateUser=SUSER_NAME() 
	WHERE convert(date, terminationdate) = '2018-12-31'

	IF (@@ROWCOUNT <> 5559999) OR (@@ERROR<>0 AND @@TRANCOUNT>0) ROLLBACK TRANSACTION
	IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END

	IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
	IF @@TRANCOUNT>0 BEGIN
	PRINT 'The database update succeeded'
	COMMIT TRANSACTION
	END
	ELSE PRINT 'The database update failed'

	IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors

END